# 「Hello World」の表示
print('Hello World')