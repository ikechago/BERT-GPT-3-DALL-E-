a = 'Test'
b = 100
c = 3.14159
print('文字列 = {}'.format(a))
print('整数 = {}'.format(b))
print('浮動小数点 = {}'.format(c))
print('浮動小数点下2桁 = {:.2f}'.format(c))
print('複数の変数 = {}, {}, {:.2f}'.format(a, b, c))