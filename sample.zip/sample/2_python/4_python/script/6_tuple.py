my_taple = (1, 2, 3, 4)
print(my_taple)
print(my_taple[0])
print(my_taple[1:3])