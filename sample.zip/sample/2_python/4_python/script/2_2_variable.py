a = 11
s = 'aは10以上' if a>10 else 'aは10未満'
print(s)