for n in [1, 2, 3]:
    print(n) # 繰り返し対象
    print(n*10) # 繰り返し対象