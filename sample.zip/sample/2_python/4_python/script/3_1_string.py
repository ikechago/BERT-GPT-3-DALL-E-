text = '''1行目のテキスト。
2行目のテキスト。'''
print(text)