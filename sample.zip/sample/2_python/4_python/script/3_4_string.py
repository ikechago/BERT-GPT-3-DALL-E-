text = 'Hello World'
print(text[1:3])
print(text[:5])
print(text[6:])