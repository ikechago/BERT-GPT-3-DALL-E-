for num, fruit in enumerate(['Apple', 'Cherry', 'Strawberry']):
    print('{}:{}'.format(num, fruit))