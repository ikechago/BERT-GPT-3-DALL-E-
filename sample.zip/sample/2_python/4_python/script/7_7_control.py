my_list1 = []
for x in range(10):
    my_list1.append(x * 2)
print(my_list1)