for n in range(5):
    print(n) # 繰り返し対象