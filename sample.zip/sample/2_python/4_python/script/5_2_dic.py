my_dic = {'Apple': 300, 'Cherry': 200, 'Strawberry': 3000}
my_dic['Apple'] = 400
print(my_dic)