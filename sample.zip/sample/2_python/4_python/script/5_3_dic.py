my_dic = {'Apple' : 300}
print(my_dic)
my_dic['Cherry'] = 200
print(my_dic)
del my_dic['Apple']
print(my_dic)