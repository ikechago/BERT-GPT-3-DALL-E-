num = 5
if num >= 10:
    print('numが10以上') # 条件が成立
else:
    print('numが10未満') # 条件が未成立