print(list(range(10)))
print(list(range(1, 7)))
print(list(range(1, 10, 2)))