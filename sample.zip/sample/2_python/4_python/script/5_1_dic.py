my_dic = {'Apple': 300, 'Cherry': 200, 'Strawberry': 3000}
print(my_dic['Apple'])