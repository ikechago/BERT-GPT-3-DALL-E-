i = 0
while i < 20:
    i += 1
    if i % 2 == 0:
        continue
    if i % 3 == 0:
        print(i)