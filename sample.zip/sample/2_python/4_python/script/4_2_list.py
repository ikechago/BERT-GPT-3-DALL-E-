my_list = [1, 2, 3, 4]
my_list[0] = 10
print(my_list)
my_list[1:4] = [20, 30]
print(my_list)