num = 10
if num >= 5:
    print('numが5以上') # 1つ目の条件が成立
elif num >= 3:
    print('numが3以上') # 2つ目の条件が成立
else:
    print('numが3未満') # 条件が未成立