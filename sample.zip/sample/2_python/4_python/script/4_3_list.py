my_list = ['Apple', 'Cherry']
print(my_list)
my_list.append('Strawberry')
print(my_list)
my_list.insert(0, 'Banana')
print(my_list)
del my_list[0]
print(my_list)
my_list.remove('Apple')
print(my_list)