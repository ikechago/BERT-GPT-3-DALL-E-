my_list2 = [x * 2 for x in range(10)]
print(my_list2)