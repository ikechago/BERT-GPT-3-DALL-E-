import openai

# APIキーの設定
openai.api_key = "<APIキー>"

# プロンプト
prompt = '''日本語を英語に翻訳します。

日本語: 吾輩は猫である
英語:'''

# 推論
response = openai.Completion.create(
    engine='davinci', 
    prompt=prompt, 
    max_tokens=30,
    stop='.')
print(prompt+response['choices'][0]['text'])