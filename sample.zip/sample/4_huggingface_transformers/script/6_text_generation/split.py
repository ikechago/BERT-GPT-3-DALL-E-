import random

# ファイルの読み込み
ds = []
with open('dataset_plain.txt') as f:
    for line in f.readlines():
        ds.append(line)

# シャッフル
random.shuffle(ds)

# ファイルを分割して保存
num = len(ds)
with open('train.txt', mode='w') as f:
    f.writelines(ds[:int(num*0.8)])
with open('dev.txt', mode='w') as f:
    f.writelines(ds[int(num*0.8):])