import os
import tensorflow_datasets as tfds
ds_test = tfds.load('wiki40b/ja', split='test')

import spacy
nlp = spacy.load('ja_ginza')

# わかぎ書き
def wakati(text):
    doc = nlp(text)
    result = ''
    for token in doc:
        result += str(token)+' '
    return result.strip()

# データセットをテキストに変換する関数
def create_txt(file_name, tf_data):
    start_paragraph = False
    count = 0

    # ファイルの書き込み
    with open(file_name, 'w') as f:
        for wiki in tf_data.as_numpy_iterator():
            for text in wiki['text'].decode().split('\n'):
                if start_paragraph:
                    text = text.replace('_NEWLINE_', '') # _NEWLINE_は削除
                    text = wakati(text)
                    f.write(text + '\n')
                    start_paragraph = False

                    # 終了
                    print(count, text)
                    count += 1
                    if count >= 100000:
                        return
                if text == '_START_PARAGRAPH_': # _START_PARAGRAPH_のみ取得
                    start_paragraph = True

# データセットをテキストに変換
create_txt('wiki_40b_test.txt', ds_test)
