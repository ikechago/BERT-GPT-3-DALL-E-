import os
import pandas as pd

# タイトルリストの取得
def get_title_list(path):
    title_list = []
    filenames = os.listdir(path)
    for filename in filenames:
        # ファイルの読み込み
        with open(path+filename) as f:
            title = f.readlines()[2].strip()
            title_list.append(title)
    return title_list
       
# データフレームの作成
df = pd.DataFrame(columns=['label', 'sentence'])
title_list = get_title_list('text/it-life-hack/')
for title in title_list:
    df = df.append({'label':0 , 'sentence':title}, ignore_index=True)
title_list = get_title_list('text/sports-watch/')
for title in title_list:
    df = df.append({'label':1 , 'sentence':title}, ignore_index=True)
title_list = get_title_list('text/movie-enter/')
for title in title_list:
    df = df.append({'label':2 , 'sentence':title}, ignore_index=True)

# シャッフル
df = df.sample(frac=1)

# CSVファイルの保存
num = len(df)
df[:int(num*0.8)].to_csv('train.csv', sep=',', index=False)
df[int(num*0.8):].to_csv('dev.csv', sep=',', index=False)