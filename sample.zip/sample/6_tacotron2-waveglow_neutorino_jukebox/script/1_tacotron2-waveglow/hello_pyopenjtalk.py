import pyopenjtalk
print(pyopenjtalk.g2p('こんにちは'))

str = pyopenjtalk.g2p(str, kana=False)
str = str.replace('pau',',')
str = str.replace(' ','')
str = str + '.'
print(str)