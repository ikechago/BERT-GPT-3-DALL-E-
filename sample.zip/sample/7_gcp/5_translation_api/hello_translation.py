from google.cloud import translate_v2 as translate

# テキスト
text = '''
吾輩は猫である。名前はまだ無い。
どこで生れたかとんと見当けんとうがつかぬ。
何でも薄暗いじめじめした所でニャーニャー泣いていた事だけは記憶している。
'''

# 英語に翻訳
translate_client = translate.Client()
result = translate_client.translate(text, target_language='en')
print(result['translatedText'])