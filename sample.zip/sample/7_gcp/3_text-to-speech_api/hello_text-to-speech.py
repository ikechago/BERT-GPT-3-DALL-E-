from google.cloud import texttospeech # (1)

# テキスト
text = '吾輩は猫である'

# 音声合成入力の準備 (2)
synthesis_input = texttospeech.SynthesisInput(text=text)

# ボイス設定の準備 (3)
voice = texttospeech.VoiceSelectionParams(
    language_code='ja-JP', # 言語コード
    ssml_gender=texttospeech.SsmlVoiceGender.NEUTRAL # 声の希望の性別
)

# オーディオ設定の準備 (4)
audio_config = texttospeech.AudioConfig(
    audio_encoding=texttospeech.AudioEncoding.LINEAR16 # オーディオ種別
)

# 音声合成の実行 (5)
client = texttospeech.TextToSpeechClient()
response = client.synthesize_speech(
    input=synthesis_input, # 音声合成入力
    voice=voice, # ボイス設定
    audio_config=audio_config # オーディオ設定
)

# 音声合成の結果の取得 (6)
with open('sample.wav', 'wb') as out:
    out.write(response.audio_content)