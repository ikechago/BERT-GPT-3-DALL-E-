from google.cloud import speech

# 音声認識入力の準備 (アップロードした音声ファイルのgsutil URIを指定) (1)
audio = speech.RecognitionAudio(uri='gs://npaka_sample1/sample.wav')

# 音声認識設定の準備
config = speech.RecognitionConfig(
    encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16, # オーディオ種別
    sample_rate_hertz=44100, # サンプルレート
    language_code='ja', # 言語コード
)

# 非同期音声認識の実行
client = speech.SpeechClient()
operation = client.long_running_recognize(
    audio=audio, # 音声認識入力
    config=config) # 音声認識設定)
response = operation.result(timeout=90)

# 非同期音声認識の結果の取得
print(response)
for result in response.results:
    print('text :', result.alternatives[0].transcript) # テキスト
    print('confidence :', result.alternatives[0].confidence) # 信頼度
