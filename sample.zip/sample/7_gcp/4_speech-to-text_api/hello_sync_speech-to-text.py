from google.cloud import speech
import io

# 音声ファイル
with io.open('sample.wav', 'rb') as audio_file:
    content = audio_file.read()

# 音声認識入力の準備 
audio = speech.RecognitionAudio(content=content)

# 音声認識設定の準備
config = speech.RecognitionConfig(
    encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16, # オーディオ種別
    sample_rate_hertz=44100, # サンプルレート
    language_code='ja', # 言語コード
)

# 同期音声合成の実行
client = speech.SpeechClient()
response = client.recognize(
    audio=audio,   # 音声認識入力
    config=config) # 音声認識設定

# 同期音声合成の結果の取得
for result in response.results:
    print('text :', result.alternatives[0].transcript) # テキスト
    print('confidence :', result.alternatives[0].confidence) # 信頼度