from google.cloud import language_v1

# テキスト (テレビに出ているその俳優は、ハリウッドで映画を作り、人気の新しいテレビ番組にも出演しています。)
text = 'That actor on TV makes movies in Hollywood and also stars in a variety of popular new TV shows.'

# コンテンツ分類の実行
document = {
    'content': text,
    'type_': language_v1.Document.Type.PLAIN_TEXT,
    'language': 'en'}
client = language_v1.LanguageServiceClient()
response = client.classify_text(request = {'document': document})

# コンテンツ分類の結果
for category in response.categories:
    # カテゴリの取得
    print('category name: {}'.format(category.name)) # カテゴリ名
    print('confidence: {:.2g}'.format(category.confidence)) # 信頼度