from google.cloud import language_v1

# テキスト
text = '銀座でランチをご一緒しましょう。'

# ドキュメントのパラメータの準備
document = {
    'content': text,
    'type_': language_v1.Document.Type.PLAIN_TEXT,
    'language': 'ja'}


# 固有表現抽出の実行
client = language_v1.LanguageServiceClient()
response = client.analyze_entities(request = {
    'document': document,
    'encoding_type': language_v1.EncodingType.UTF8})

# 固有表現抽出の結果
for entity in response.entities:
    print('entity name: {}'.format(entity.name)) # 固有表現の名前
    print('entity type: {}'.format(language_v1.Entity.Type(entity.type_).name)) # 固有表現の種別
    print('score: {}'.format(entity.salience)) # テキスト全体の関連性スコア (0.0〜1.0)
    for metadata_name, metadata_value in entity.metadata.items():
        print('    {}: {}'.format(metadata_name, metadata_value)) # 固有表現のメタデータ
    for mention in entity.mentions:
        print('    mention text: {}'.format(mention.text.content)) # メンションのテキスト
        print('    mention type: {}'.format(language_v1.EntityMention.Type(mention.type_).name)) # メンションの種別
    print('')