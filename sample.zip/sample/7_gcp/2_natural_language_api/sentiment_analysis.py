from google.cloud import language_v1

# テキスト
text = '私は幸せです'

# ドキュメントのパラメータの準備
document = {
    'content': text,
    'type_': language_v1.Document.Type.PLAIN_TEXT,
    'language': 'ja'}


# 感情分析の実行
client = language_v1.LanguageServiceClient()
response = client.analyze_sentiment(request = {
    'document': document,
    'encoding_type': language_v1.EncodingType.UTF8})

# 感情分析の結果
print('score: {:.2g}'.format(response.document_sentiment.score))
print('magnitude: {:.2g}'.format(response.document_sentiment.magnitude))