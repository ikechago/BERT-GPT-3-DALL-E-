from google.cloud import language_v1

# テキスト
text = '銀座でランチをご一緒しましょう。'

# 係り受け解析の実行
document = {
    'content': text,
    'type_': language_v1.Document.Type.PLAIN_TEXT,
    'language': 'ja'}
client = language_v1.LanguageServiceClient()
response = client.analyze_syntax(request = {
    'document': document,
    'encoding_type': language_v1.EncodingType.UTF8})

# 文章を単語に分割
for token in response.tokens:
    # テキストの取得
    text = token.text
    print('token content: {}'.format(text.content)) # テキスト
    print('token begin_offset: {}'.format(text.begin_offset)) # 位置

    # 品詞の取得
    part_of_speech = token.part_of_speech
    print('part_of_speech tag: {}'.format(language_v1.PartOfSpeech.Tag(part_of_speech.tag).name)) # 品詞

    # レンマの取得
    print('lemma: {}'.format(token.lemma))

    # 依存関係の取得
    dependency_edge = token.dependency_edge
    print('dependency_edge head_token_index: {}'.format(dependency_edge.head_token_index)) # ヘッドトークンインデックス
    print('dependency_edge label: {}'.format(language_v1.DependencyEdge.Label(dependency_edge.label).name)) # ラベル
    print()